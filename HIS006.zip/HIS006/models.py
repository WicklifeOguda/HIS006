from sqlalchemy import Column, String, Date, Float, Integer


from db import Base


class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, autoincrement=True)
    first_name = Column(String)
    middle_name = Column(String)
    last_name = Column(String)
    gender = Column(String)
    date_of_birth = Column(Date)
    height = Column(Float)
    weight = Column(Float)
    temperature = Column(Float)
    blood_pressure = Column(String)
    heart_rate = Column(Integer)
    county = Column(String)
    sub_county = Column(String)
    ward = Column(String)
    village = Column(String)
    visit_date = Column(Date)
    next_appointment_date = Column(Date)
    doctor = Column(String)
    illness = Column(String)
    prescription = Column(String)
