import csv
import models
from db import engine, SessionLocal
from datetime import datetime
from models import Patient

models.Base.metadata.create_all(bind=engine)


def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


def insert_csv_to_db(db):
    with open("Patient List.csv", "r") as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            patient = Patient(
                first_name=row["First Name"],
                middle_name=row["Middle Name"],
                last_name=row["Last Name"],
                gender=row["Gender"],
                date_of_birth=datetime.strptime(
                    row["Date of Birth"], "%m/%d/%Y"
                ).date(),
                height=float(row["Height (m)"]),
                weight=float(row["Weight (kg)"]),
                temperature=float(row["Temperature (°C)"]),
                blood_pressure=row["Blood Pressure"],
                heart_rate=int(row["Heart Rate (bpm)"]),
                county=row["County"],
                sub_county=row["Sub County"],
                ward=row["Ward"],
                village=row["Village"],
                visit_date=datetime.strptime(row["Visit Date"], "%m/%d/%Y").date(),
                next_appointment_date=datetime.strptime(
                    row["Next Appointment Date"], "%m/%d/%Y"
                ).date(),
                doctor=row["Doctor"],
                illness=row["Illness"],
                prescription=row["Prescription"],
            )
            db.add(patient)

        db.commit()


def upload_csv():
    db = next(get_db())
    try:
        insert_csv_to_db(db)
        print("Data uploaded successfully!")
    except Exception as e:
        print(f"An error occurred: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    upload_csv()
